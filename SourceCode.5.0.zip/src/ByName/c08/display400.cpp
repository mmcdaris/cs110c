void displayDiameter(Sphere thing)
{
   cout << "The diameter is "
        << thing.getDiameter() << ".\n";
}  // end displayDiameter
