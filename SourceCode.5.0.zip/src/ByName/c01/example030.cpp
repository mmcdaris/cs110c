// computes the sum of item[0], item[1], ...,
// item[n - 1] for any n >= 1
int sum = 0;
int j = 0;

while (j < n)
{  sum += item[j];
   ++j;
}  // end while
