#include "QueueP.h"

int main()
{
   Queue aQueue;

   aQueue.enqueue(15);

   return 0;
} // end main
