void useColoredSphere()
{
   ColoredSphere ball(RED);
   ball.setRadius(5.0);
   cout << "The ball diameter is " << ball.getDiameter();
   ball.setColor(BLUE);
}  // use ColoredSphere
