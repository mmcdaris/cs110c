int index = 0;
int sum = item[0];

while (index < n)
{  ++index;
   sum += item[index];
}  //end while
