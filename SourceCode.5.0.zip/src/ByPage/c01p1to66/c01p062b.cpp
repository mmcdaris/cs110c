double compute(double x)
{
  return sqrt(x) / cos(x);
}  // end compute
