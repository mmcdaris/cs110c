num = 50;

while (num >= 0)
{  cout << num << endl;
   num = num + 1;
}  // end while
