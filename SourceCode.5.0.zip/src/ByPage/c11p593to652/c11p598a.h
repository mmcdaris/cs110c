#include <string>

using namespace std;

class City
{
public:
//   . . .
   // methods for accessing private data members
private:
   string cityName; // city's name
   string country;  // city's country
   int    pop;      // city's population
}; // end City
