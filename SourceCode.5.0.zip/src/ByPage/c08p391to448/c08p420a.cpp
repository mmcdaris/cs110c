int SortedList::sortedGetLength()
{
   return getLength();
}  // end sortedGetLength
