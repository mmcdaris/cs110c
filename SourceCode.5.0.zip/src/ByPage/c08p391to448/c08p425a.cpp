template <typename T>
void NewClass<T>::display()
{
   cout << theData;
}  // end display
