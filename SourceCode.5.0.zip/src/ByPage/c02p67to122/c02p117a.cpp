// Exercise 6

void printNum(int n)
{
   cout << n << endl;
   printNum(n-1);
}  // end printNum
