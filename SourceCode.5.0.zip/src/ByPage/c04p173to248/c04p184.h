struct Node
{  int   item;
   Node *next;
}; // end Node
