typedef Person ItemType;

struct Node
{  ItemType item;
   Node    *next;
}; // end Node

Node *head;
