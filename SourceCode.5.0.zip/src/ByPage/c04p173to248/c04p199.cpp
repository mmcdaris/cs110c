/** @file ListP.cpp
 *  ADT list - Pointer-based implementation. */

#include <cstddef>     // for NULL
#include <new>         // for bad_alloc
#include "ListP.h"     // header file

using namespace std;

// definitions of methods follow:
//   . . .
